package com.sdettraining.setpdefination;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class setpdef extends BaseTest {

	@Given("^User navigate to retails application$")
	public void user_navigate_to_retails_application() throws Throwable {

		System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.get("http://retailm1.upskills.in/");
		driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
	}

	@Given("^User validate the registration page$")
	public void user_validate_the_registration_page() throws Throwable {
		driver.findElement(By.xpath("")).sendKeys("");

	}

	@When("^User click on accont link$")
	public void user_click_on_accont_link() throws Throwable {
		driver.findElement(By.xpath("")).click();

	}

	@When("^User click on Login/Register link$")
	public void user_click_on_Login_Register_link() throws Throwable {
		driver.findElement(By.xpath("")).click();

	}

	@When("^User click on register button$")
	public void user_click_on_register_button() throws Throwable {

		driver.findElement(By.xpath("")).click();
	}

	@When("^User enter first name \"([^\"]*)\"$")
	public void user_enter_first_name(String arg1) throws Throwable {
		driver.findElement(By.xpath("")).sendKeys("");

	}

	@When("^User enter last name \"([^\"]*)\"$")
	public void user_enter_last_name(String arg1) throws Throwable {
		driver.findElement(By.xpath("")).sendKeys("");

	}

	@When("^User enter email \"([^\"]*)\"$")
	public void user_enter_email(String arg1) throws Throwable {
		driver.findElement(By.xpath("")).sendKeys("");

	}

	@When("^User enter telephone \"([^\"]*)\"$")
	public void user_enter_telephone(String arg1) throws Throwable {

		driver.findElement(By.xpath("")).sendKeys("");
	}

	@When("^User enter address(\\d+) \"([^\"]*)\"$")
	public void user_enter_address(int arg1, String arg2) throws Throwable {
		driver.findElement(By.xpath("")).sendKeys("");

	}

	@When("^User enter city \"([^\"]*)\"$")
	public void user_enter_city(String arg1) throws Throwable {
		driver.findElement(By.xpath("")).sendKeys("");

	}

	@When("^User enter postcode \"([^\"]*)\"$")
	public void user_enter_postcode(String arg1) throws Throwable {
		driver.findElement(By.xpath("")).sendKeys("");

	}

	@When("^User select country \"([^\"]*)\"$")
	public void user_select_country(String arg1) throws Throwable {
		driver.findElement(By.xpath("")).sendKeys("");

	}

	@When("^User select region/state \"([^\"]*)\"$")
	public void user_select_region_state(String arg1) throws Throwable {
		driver.findElement(By.xpath("")).sendKeys("");

	}

	@When("^User enter password \"([^\"]*)\"$")
	public void user_enter_password(String arg1) throws Throwable {
		driver.findElement(By.xpath("")).sendKeys("");

	}

	@When("^User enter passwordconfirm \"([^\"]*)\"$")
	public void user_enter_passwordconfirm(String arg1) throws Throwable {
		driver.findElement(By.xpath("")).sendKeys("");

	}

	@When("^User click on no subscribe button$")
	public void user_click_on_no_subscribe_button() throws Throwable {

		driver.findElement(By.xpath("")).sendKeys("");
	}

	@Then("^I validate user register successfully$")
	public void i_validate_user_register_successfully() throws Throwable {
		driver.findElement(By.xpath("")).sendKeys("");
	}
}